import { readFileSync } from "node:fs";

const marker = "STREAM_CUMULATIVE_BENCHMARK ";

function read(path) {
  const line = readFileSync(new URL(path, import.meta.url), "utf8")
    .split("\n")
    .find((entry) => entry.startsWith(marker));
  if (line === undefined) throw new Error(`Missing benchmark result in ${path}`);
  return JSON.parse(line.slice(marker.length));
}

function median(values) {
  const sorted = values.toSorted((left, right) => left - right);
  const middle = Math.floor(sorted.length / 2);
  return sorted.length % 2 === 1
    ? sorted[middle]
    : (sorted[middle - 1] + sorted[middle]) / 2;
}

function pairedCampaign({ directory, mainPrefix, candidatePrefix, rounds }) {
  const metrics = ["live_delivery_one_subscriber", "live_delivery_25_subscribers"];
  return Object.fromEntries(
    metrics.map((metric) => {
      const pairs = Array.from({ length: rounds }, (_, index) => {
        const round = index + 1;
        const main = read(`${directory}/${mainPrefix}${round}.log`).metrics[metric];
        const candidate = read(`${directory}/${candidatePrefix}${round}.log`).metrics[metric];
        const delta = (candidateValue, mainValue) =>
          ((candidateValue / mainValue - 1) * 100);
        return {
          round,
          p50Percent: delta(candidate.p50Ms, main.p50Ms),
          p95Percent: delta(candidate.p95Ms, main.p95Ms),
          meanPercent: delta(candidate.meanMs, main.meanMs),
          ...(candidate.operationsPerSecond === undefined
            ? {}
            : {
                throughputPercent: delta(
                  candidate.operationsPerSecond,
                  main.operationsPerSecond,
                ),
              }),
        };
      });
      const names = Object.keys(pairs[0]).filter((name) => name !== "round");
      return [
        metric,
        {
          pairs,
          medianPairDelta: Object.fromEntries(
            names.map((name) => [name, median(pairs.map((pair) => pair[name]))]),
          ),
        },
      ];
    }),
  );
}

const output = {
  exactMain: {
    baseRevision: "832baef84eea74446e10bdceed6d162b3e935914",
    candidateRevision: "f8a0dfb5d",
    paired: pairedCampaign({
      directory: "logs-current",
      mainPrefix: "stream-wake-current-main-20260717-paired-main-r",
      candidatePrefix: "stream-wake-current-main-20260717-paired-wake-r",
      rounds: 6,
    }),
  },
  historical: {
    baseRevision: "7f70432e0",
    isolatedPatchRevision: "4db0e0236",
    paired: pairedCampaign({
      directory: "logs-historical",
      mainPrefix: "stream-wake-current-main-main-r",
      candidatePrefix: "stream-wake-current-main-wake-r",
      rounds: 5,
    }),
  },
};

console.log(JSON.stringify(output, null, 2));
