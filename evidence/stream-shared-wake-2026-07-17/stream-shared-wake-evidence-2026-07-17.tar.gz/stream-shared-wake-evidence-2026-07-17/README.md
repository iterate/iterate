# Shared resident wake evidence

Captured 2026-07-17 after merging exact `origin/main`
`832baef84eea74446e10bdceed6d162b3e935914` into draft PR #1902.

## Decision

This is the only small Stream Durable Object optimization from the larger
branch that is worth considering as a direct port to main. It publishes one
immutable core-state snapshot per wake to all resident connections and lets
each connection coalesce notifications while its delivery pump is active.
That removes per-subscriber core-state reads, redundant async pump calls, and
the caught-up SQLite probe after each delivered event.

The patch is `shared-wake.patch`; its local branch is
`stream-shared-wake-main-20260717` and its commit is
`f8a0dfb5d`. It changes one file by 26 additions and 8 deletions. It changes no
public API, schema, durable state, alarm, service, or network boundary and can
be reverted without migration.

Do not bundle a second optimization with it. The next-smallest measured idea,
internal append-response elision, is about 100 lines, narrower, and entangled
with append API decisions. The broader rewrite remains parked.

## Verification

- `stream-subscribers.test.ts` and `stream-subscribers.teardown.test.ts`: 42/42
  passed.
- OS TypeScript check passed, including route and Wrangler generation.
- `oxfmt --check` passed.
- Every benchmark process passed its focused Vitest test.

All latency samples were taken by the Node host around awaited append and
host-observed callback completion. No result depends on a Worker-local clock
advancing while Cloudflare has no network I/O.

## Results

The cleaner historical campaign compared base `7f70432e0` with the first
isolated form of this patch. Across five paired 300-sample rounds, the median
pair delta for 25 resident subscribers was 7.48% lower p50, 11.96% lower p95,
7.51% lower mean, and 8.08% higher throughput. One-subscriber p50 was neutral
at 0.17% lower.

The fresh exact-main campaign used base `832baef84` and candidate `f8a0dfb5d`.
Six tightly paired, alternating 200-sample rounds ran with both warmed servers
resident. Median pair deltas for 25 subscribers were 5.05% lower p50, 5.46%
lower p95, 6.70% lower mean, and 5.34% higher throughput. One-subscriber
results were noisy and neutral: p50 was 6.16% worse while p95 and mean were
5.84% and 2.64% better.

The machine was heavily shared during the fresh campaign. One candidate round
ran while unrelated `tsgo` and Node processes drove load above 8 and produced
40-100 ms tails. It is retained in the raw logs. Median paired deltas, rather
than pooled tails or selected runs, are the fresh summary. Taken with the
cleaner prior campaign, the defensible claim is a roughly 5-8% resident
fan-out improvement and no demonstrated singleton improvement.

## Contents

- `shared-wake.patch`: mail-formatted patch on exact main.
- `analysis.mjs`: dependency-free paired analysis.
- `analysis.json`: its captured output.
- `logs-current/`: five 300-sample rounds per arm plus six tightly paired
  200-sample rounds per arm.
- `logs-historical/`: five cleaner 300-sample rounds per arm.
- `server-logs/`: final local workerd/Vite server logs for each exact-main arm.

Run `node analysis.mjs` from this directory to reproduce `analysis.json`.
